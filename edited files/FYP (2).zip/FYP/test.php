


<input type="text" value=<?php echo $_SESSION['user_name']; ?> >