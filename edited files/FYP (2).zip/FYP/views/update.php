<link rel="stylesheet" type="text/css" href="css/login2.css"/>

<meta name="viewport" content="width=device-width, initial-scale=0.6">

<!-- register form -->
<form method="post" action="register.php" name="registerform" class="login-form">


<p class="login-text">

<span>
<img src="images/info.png">
</span>
<br>
Update Your information by simply few steps

<br><br>


    <!-- the user name input field uses a HTML5 pattern check -->


    <input id="login_input_username" class="login-username"   type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" placeholder="Username (only letters and numbers, 2 to 64 characters)" required size=100px />

<br>

    <!-- the email input field uses a HTML5 email type check -->


    <input id="login_input_email" class="login-username" type="email" name="user_email" placeholder="User Email"required />



<br>


    <input id="login_input_password_new" class="login-username" type="password" name="user_password_new" pattern=".{6,}" required autocomplete="off" placeholder="password" />

<br>

    <input id="login_input_password_repeat" class="login-username" type="password" name="user_password_repeat" pattern=".{6,}" required autocomplete="off" placeholder="repeat password" />

<br>
    <input type="submit"  name="register" value="Register" class="login-submit" />

</p>

<p class="login-text2">
<?php
// show potential errors / feedback (from registration object)
if (isset($registration)) {
    if ($update->errors) {
        foreach ($update->errors as $error) {
            echo $error;
        }
    }
    if ($update->messages) {
        foreach ($update->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>
</form>

<!-- backlink -->


<div class="underlay-photo"></div>
<div class="underlay-black"></div> 

<script src="js/speech-input.js"></script>
