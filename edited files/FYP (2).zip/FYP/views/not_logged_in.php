

<link rel="stylesheet" type="text/css" href="css/login.css"/>
<link rel="stylesheet" href="css/speech-input.css">

<meta name="viewport" content="width=device-width, initial-scale=0.7">

<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform">

<p class="login-text">

<span>
<img src="images/logo.png"><br>

Login  The Voice Calendar by simply
few step
</span>

<div class="si-wrapper">                   

 <input id="login_input_username" class="si-input login-username login_input" type="text" name="user_name" placeholder="Name" size=45px x-webkit-speech required   />           

<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>



<br>
<div class="si-wrapper">                   

     <input id="login_input_password" class="si-input login-username login-password" type="password" name="user_password"  required="true" placeholder="Password" required />

<button class="si-btn2" id="login_input_password_voicebtn">
		speech input
		<span class="si-mic"></span>
		<span class="si-holder"></span>
	</button>
</div>

    

    <input type="submit"  name="login" value="Log in"  class="login-submit"/>
  </p>

 <script type="text/javascript">
document.getElementById("login_input_username_voicebtn").click();
</script>

<p class="login-text2">

<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>


</form>






<a href="register.php" class="login-forgot-pass">No Account?Register the account now</a>
<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/voice.js"></script>
<script src="js/speech-input.js"></script>

