

<link rel="stylesheet" type="text/css" href="login.css"/>
<link rel="stylesheet" href="speech-input2.css">



<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform">

<p class="login-text">

<span>
<img src="logo.png"><br>

Login  The Voice Calendar by simply
few step
</span>
<input id="login_input_username" class="login-username"  class="login_input" type="text" name="user_name" placeholder="Name" size=45px x-webkit-speech required   />


<br>
    <input id="login_input_password" class="login-username"  type="password" name="user_password" class="login-password" required="true" placeholder="Password" required />


    <input type="submit"  name="login" value="Log in"  class="login-submit"/>
  </p>


<p class="login-text2">

<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>


</form>






<a href="register.php" class="login-forgot-pass">No Account?Register the account now</a>
<div class="underlay-photo"></div>
<div class="underlay-black"></div> 

<script src="speech-input.js"></script>

