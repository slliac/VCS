

<link rel="stylesheet" type="text/css" href="css/login.css"/>
<link rel="stylesheet" href="css/speech-input2.css">

<meta name="viewport" content="width=device-width, initial-scale=0.7">

<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform">

<p class="login-text">

<span>
<img src="images/logo.png"><br>

Login  The Voice Calendar by simply
few step
</span>
<input id="login_input_username" class="login-username"  class="login_input" type="text" name="user_name" placeholder="Name" size=45px x-webkit-speech required   />


<br>
    <input id="login_input_password" class="login-username"  type="password" name="user_password" class="login-password" required="true" placeholder="Password" required />


    <input type="submit"  name="login" value="Log in"  class="login-submit"/>
  </p>

 <?php echo " <script type=\"text/javascript\">
		document.getElementById('login_input_username').Focus();
         
         </script>
        ";
		?>
<p class="login-text2">

<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>


</form>






<a href="register.php" class="login-forgot-pass">No Account?Register the account now</a>
<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/voice.js"></script>
<script src="js/speech-input.js"></script>

