
var colors = { 
    logout:  'logout', 
    lockout: 'lockout',
    listen:  'listen',
    create: 'create',
    save: 'save',
	close: 'close',
};
var keys = Object.keys( colors );
var speech = new webkitSpeechRecognition();
speech.language = 'en-US';
speech.continuous = true;
speech.interimResults = true;
speech.onresult = function( e ) {
    if ( e.results[e.results.length-1].isFinal) {
      var said = e.results[e.results.length-1][0].transcript.toLowerCase();
      //output.textContent = said;
	  console.log(said);
        //for (var i = keys.length - 1; i >= 0; i--) {
            var sanitized_said = said.trim().replace( ' ', '' );

            if ( sanitized_said === 'speak' ) {
                //login.html
				document.getElementById("speak").click();
                //window.location.href = 'login.html'//'http://www.google.com';
            } 
			
			else if ( sanitized_said === 'create') {
				document.getElementById("faddbtn").click();//ok now!!!!
			}
			
		
			else if ( sanitized_said === 'save'|| sanitized_said === 'safe') {
				document.getElementById("Savebtn").click();
			}
			
			else if ( sanitized_said === 'delete') {
				document.getElementById("Deletebtn").click();
			}
			
			else if ( sanitized_said === 'close') {
				document.getElementById("Closebtn").click();
			}
			
			
			
			
		
			else if ( sanitized_said === 'lockout' || sanitized_said === 'logout' ) {
                window.location.href = 'index.php?logout';//Please insert the logout function before this statement
            } else if ( sanitized_said === 'insert'|| sanitized_said === 'new') {
				(function(e) {
				
                //var url ="edit.php";
                //OpenModelWindow(url,{ width: 500, height: 400, caption: "Create New Calendar"});
            });
				//document.getElementByClass("bubble-sprite").click();
				//window.Edit(data);
				//document.getElementById().click();
			}
        //};
    };
}

speech.start();