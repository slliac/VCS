

<link rel="stylesheet" type="text/css" href="login2.css"/>



<!-- register form -->
<form method="post" action="register.php" name="registerform" class="login-form">


<p class="login-text">

<span>
<img src="info.png">
</span>
<br>
Register your Voice Calendar by free<br>Just input fews things for registers

<br><br>


    <!-- the user name input field uses a HTML5 pattern check -->


    <input id="login_input_username" class="login-username"   type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" placeholder="Username (only letters and numbers, 2 to 64 characters)" required size=100px />

<br>

    <!-- the email input field uses a HTML5 email type check -->


    <input id="login_input_email" class="login-username" type="email" name="user_email" placeholder="User Email"required />



<br>


    <input id="login_input_password_new" class="login-username" type="password" name="user_password_new" pattern=".{6,}" required autocomplete="off" placeholder="password" />

<br>

    <input id="login_input_password_repeat" class="login-username" type="password" name="user_password_repeat" pattern=".{6,}" required autocomplete="off" placeholder="repeat password" />

<br>
    <input type="submit"  name="register" value="Register" class="login-submit" />

</p>

<p class="login-text2">
<?php
// show potential errors / feedback (from registration object)
if (isset($registration)) {
    if ($registration->errors) {
        foreach ($registration->errors as $error) {
            echo $error;
        }
    }
    if ($registration->messages) {
        foreach ($registration->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>
</form>

<!-- backlink -->


<div class="underlay-photo"></div>
<div class="underlay-black"></div> 

<script src="speech-input.js"></script>



