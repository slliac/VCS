<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Page</title>


<style type="text/css">
.poi {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
}
#left p {
	font-weight: bold;
	font-family: Verdana, Geneva, sans-serif;
	color: #36C;
	font-size: 12px;
}
fgh {
	font-size: 9px;
}
bef {
	font-size: 9px;
}
.fer {
	font-size: 12px;
	color: #0FF;
}
.abc {
	font-size: 12px;
}
.a {
	font-size: 14px;
}
.SS {
	color: #C03;
}
.sta {
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
}
#right p {
	font-family: Verdana, Geneva, sans-serif;
	font-weight: bold;
}
.asd {
	color: #66F;
}
</style>
<link href="index.css" rel="stylesheet" type="text/css" />
</head>

<body>
<p><img src="logo.png" width="249" height="95" align="left"/>
  
  <br>
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><br>
  
  
  <img src="wall.png" width=100% height="301" /></p>
<div id="left">
  <p class="SS">Now you are login as:  </p>
  
 <div id="admin"><?php echo $_SESSION['user_name']; ?><A HREF="main.php"><img src="Entypo_e78e(0)_32.png" width="32" height="32" /><BR>
  </a> </div>
  <span class="sta"><a href="index.php?logout">[logout]</a></span>
  <br><br>
  <div class="a" id="currentpage"><img src="Entypo_2691(0)_32.png" width="32" height="32" />Current:index.html
</div>
  <p><img src="Entypo_e792(0)_32.png" width="32" height="32" />Your Page Index:<br> 
<img src="Entypo_2712(0)_32.png" width="32" height="32" /> <a href="view.php">Profile</a></p>
  <p><span class="asd"><img src="Entypo_d83d(0)_32.png" width="32" height="32" /><a href="backup.html">Backup </a></span></p>
  <p><img src="Entypo_e754(0)_32.png" width="32" height="32" /><a href="restore.html">Restore</a></p>
  <p>&nbsp;</p>
  
</div>





<div id="right">
  <div id="update">Recent Update<img src="Entypo_e70c(0)_32.png" width="32" height="32" /></div>

  <p>[19/4/2015] Testing Version 1.0 </p>
  <p>[18/4/2015] View of User profile established</p>
  <p>[3/1/2015] Adminstration Page Update</p>
  <p>[2/1/2015] Login Page Setup</p>
  <p>[1/1/2015] User Main Page Setup</p>
  <p>&nbsp;</p>
<p>&nbsp;</p>
</div>


<p><hr></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p class="poi">

Copyright Google Voice Calender Admin Version 1.0 2015
<BR>ISD02
Final Year Project in Information System Development<br>
Community College of City University</p>
</body>
</html>