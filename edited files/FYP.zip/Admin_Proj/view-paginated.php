
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Page</title>


<style type="text/css">
.poi {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
}
#left p {
	font-weight: bold;
	font-family: Verdana, Geneva, sans-serif;
	color: #C00;
	font-size: 12px;
}
fgh {
	font-size: 9px;
}
bef {
	font-size: 9px;
}
.fer {
	font-size: 12px;
	color: #0FF;
}
.abc {
	font-size: 12px;
}
.a {
	font-size: 14px;
}
.SS {
	color: #C03;
}
.sta {
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
}
#right p {
	font-family: Verdana, Geneva, sans-serif;
	font-weight: bold;
}
</style>
<link href="index.css" rel="stylesheet" type="text/css" />
</head>

<body>
<p><img src="logo.png" width="249" height="95" align="left"/>
  
  <br>
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><br>
  
  
  <img src="wall.png" width=100% height="301" /></p>
<div id="left">
  <p class="SS">Now yare login as:  </p>
  
 <div id="admin">Admin1234<A HREF="login.html"><img src="Entypo_e78e(0)_32.png" width="32" height="32" /><BR>
  </a> </div>
  <span class="sta"><a href="login.html">[logout]</a></span>
  <br><br>
  <div class="a" id="currentpage"><img src="Entypo_2691(0)_32.png" width="32" height="32" />Current:View.php
</div>

  <p><img src="Entypo_e792(0)_32.png" width="32" height="32" />Your Page Index: 
  <br>
    <br>
 <img src="Entypo_2712(0)_32.png" width="32" height="32" /> <a href="Activity.html">Activity</a>
 <br>
 <img src="Entypo_2712(0)_32.png" width="32" height="32" /> <a href="Account.html">Account</a>
  <br>
 <img src="Entypo_2712(0)_32.png" width="32" height="32" /> <a href="view.php">Profile</a></p>
  <p><span class="asd"><img src="Entypo_d83d(0)_32.png" width="32" height="32" /><a href="backup.html">Backup </a></span></p>
  <p><img src="Entypo_e754(0)_32.png" width="32" height="32" /><a href="restore.html">Restore</a></p>
  <p>&nbsp;</p>
  
</div>



<div id="right">
  <div id="update">
    <form>
 <fieldset>
  <legend>Searching for:</legend>
  


<body>

<?php
/* 
	VIEW-PAGINATED.PHP
	Displays all data from 'players' table
	This is a modified version of view.php that includes pagination
*/

	// connect to the database
	include('connect-db.php');
	
	// number of results to show per page
	$per_page = 3;
	
	// figure out the total pages in the database
	$result = mysql_query("SELECT * FROM users");
	$total_results = mysql_num_rows($result);
	$total_pages = ceil($total_results / $per_page);

	// check if the 'page' variable is set in the URL (ex: view-paginated.php?page=1)
	if (isset($_GET['page']) && is_numeric($_GET['page']))
	{
		$show_page = $_GET['page'];
		
		// make sure the $show_page value is valid
		if ($show_page > 0 && $show_page <= $total_pages)
		{
			$start = ($show_page -1) * $per_page;
			$end = $start + $per_page; 
		}
		else
		{
			// error - show first set of results
			$start = 0;
			$end = $per_page; 
		}		
	}
	else
	{
		// if page isn't set, show first set of results
		$start = 0;
		$end = $per_page; 
	}
	
	// display pagination
	
	echo "<p><a href='view.php'>View All</a> | <b>View Page:</b> ";
	for ($i = 1; $i <= $total_pages; $i++)
	{
		echo "<a href='view-paginated.php?page=$i'>$i</a> ";
	}
	echo "</p>";
		
	// display data in table
	echo "<table border='1' cellpadding='10'>";
	echo "<tr> <th>ID</th> <th>User Name</th> <th>User Email</th> <th></th> <th></th></tr>";

	// loop through results of database query, displaying them in the table	
	for ($i = $start; $i < $end; $i++)
	{
		// make sure that PHP doesn't try to show results that don't exist
		if ($i == $total_results) { break; }
	
		// echo out the contents of each row into a table
		echo "<tr>";
		echo '<td>' . mysql_result($result, $i, 'user_id') . '</td>';
		echo '<td>' . mysql_result($result, $i, 'user_name') . '</td>';
		echo '<td>' . mysql_result($result, $i, 'user_email') . '</td>';
		echo '<td><a href="edit.php?id=' . mysql_result($result, $i, 'user_id') . '">Edit</a></td>';
		echo '<td><a href="delete.php?id=' . mysql_result($result, $i, 'user_id') . '">Delete</a></td>';
		echo "</tr>"; 
	}
	// close table>
	echo "</table>"; 
	
	// pagination
	
?>
<br><br><br><br><br><br><br><br><br><br><br><br>
</fieldset>




</body>
</html>