<?php

if(isset($_POST['update']))
{

$dbhost = 'localhost';
$dbuser = 'root';
$dbname = "jqcalendar";

$conn = mysql_connect($dbhost, $dbuser, $dbname);

if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

} 

$login_input_username= $_POST['user_name'];

$login_input_email= $_POST['user_email'];

$sql = "UPDATE users SET user_name = $login_input_username WHERE user_name = '".$_SESSION['user_name']."' " ;

if ($conn->query($sql) === TRUE) {

    echo "Record updated successfully";
} 

else 
{

echo "Error updating record: " . $conn->error;

}

$conn->close();

}

?>
