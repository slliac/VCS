

<link rel="stylesheet" type="text/css" href="css/login2.css"/>
<link rel="stylesheet" href="css/speech-input.css">
<meta name="viewport" content="width=device-width, initial-scale=0.7">

<!-- register form -->
<form method="post" action="register.php" name="registerform" class="login-form">


<p class="login-text">

<span>
<img src="images/info.png">
</span>
<br>
Register your Voice Calendar by free<br>Just input fews things for registers

<br><br>


    <!-- the user name input field uses a HTML5 pattern check -->

<div class="si-wrapper">      
    <input id="login_input_username" class="login-username  si-input "   type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" placeholder="Username (only letters and numbers, 2 to 64 characters)" required size=100px />

<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>
<BR>

    <!-- the email input field uses a HTML5 email type check -->

<div class="si-wrapper">      
    <input id="login_input_email" class="login-username  si-input " type="text" name="user_email" placeholder="User Email"required size=100px />
<button class="si-btn2" id="login_input_username_voicebtn" >
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>

<BR>

<div class="si-wrapper">      
    <input id="login_input_password_new" class="login-username  si-input " type="password" name="user_password_new" pattern=".{6,}" required autocomplete="off" placeholder="password" required size=100px />
<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>
<BR>

<div class="si-wrapper">      
    <input id="login_input_password_repeat" class="login-username  si-input " type="password" name="user_password_repeat" pattern=".{6,}" required autocomplete="off" placeholder="repeat password" required size=100px />
<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>

<BR>


    <input type="submit"  name="register" value="Register" id="registerbtn" class="login-submit" />
    <input type="button"  value="Back to main page"  class="login-submit" onclick="window.location.href='index.php'" />

</p>

<p class="login-text2">
<?php
// show potential errors / feedback (from registration object)
if (isset($registration)) {
    if ($registration->errors) {
        foreach ($registration->errors as $error) {
            echo $error;
        }
    }
    if ($registration->messages) {
        foreach ($registration->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>
</form>

<!-- backlink -->


<audio autoplay>
 <source src="voice/name2.mp3" type="audio/mpeg">
</audio>

<audio id="myaudio2" src="voice/email.mp3" ></audio>

<input type="hidden" id="audio2" onclick="document.getElementById('myaudio2').play()">

<audio id="myaudio3" src="voice/pw2.mp3" ></audio>

<input type="hidden" id="audio3" onclick="document.getElementById('myaudio3').play()">

<audio id="myaudio4" src="voice/confirm.mp3" ></audio>

<input type="hidden" id="audio4" onclick="document.getElementById('myaudio4').play()">





<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/control2.js"></script>
<script src="js/speech-input.js"></script>



