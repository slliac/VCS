
<?php 
session_start();
?>

<meta name="viewport" content="width=device-width, initial-scale=0.7">

<link rel="stylesheet" href="css/speech-input.css">

<link rel="stylesheet" type="text/css" href="css/login3.css"/>

<meta name="viewport" content="width=device-width, initial-scale=0.6">

<!-- register form -->

<form action="http://formtoemail.com/user_forms.php" method="post" class="login-form" name="loginform" id="form" >

<input type="hidden" name="user_id" value="G40UQLNX41XQ63BDX1TD">
<input type="hidden" name="form_id" value="1">

<p class="login-text">

<span>
<img src="images/info.png">
</span>


<br>
Contact Your Adminstrators by simply few steps<br>
Account Problem,Email Problem Whatever!

    <!-- the user name input field uses a HTML5 pattern check -->
<align="center">
<h4></h4>

 <br><br>Case Name:<br> 
<div class="si-wrapper"> <input id="user_name" class="login-username  si-input"  type="text" name="
Dear Adminstrator:

Here are the comments given by Our Client,please take a look and manages their case.

Your Case is" placeholder="Enter Case Title"/>
<span></span>
<button class="si-btn2" id="login_input_username_voicebtn">
speech input
<span class="si-mic" ></span>
<span class="si-holder"></span>
</button>

</div>

  <input type="hidden" name="Your Client Name:"  value=<?php echo $_SESSION['user_name'];?>  >


<br>

    <!-- the email input field uses a HTML5 email type check -->


 <br><br> Contact EMail of the user:<br>
    <input id="user_email" class="login-username si-input" type="text" name="user email" placeholder="User Email"  value=<?php echo $_SESSION['user_email'];?>  required />
<br>


<br><br>
Your Request:<br>
<div class="si-wrapper"> 
<input type="text" name="comment" class="login-username si-input"  style="width:100%;margin:0 0 10px;" placeholder="Leave Your Comments" id="comment">
<span></span>
<button class="si-btn2" id="login_input_comment_voicebtn">
speech input
<span class="si-mic" ></span>
<span class="si-holder"></span>
</button>

</div>


  <input type="hidden" name="
Best Regards,

Voice Calendar Automatic System Center"  value=" ">


<br>


<audio autoplay>
 <source src="voice/case.mp3" type="audio/mpeg">
</audio>


<audio id="myaudio" src="voice/request.mp3" ></audio>

<input type="hidden" id="audio" onclick="document.getElementById('myaudio').play()">

<br>
    <input type="submit" id="submit" value="Send your request" class="login-submit" />

    <input type="button"  value="Back to main page"  class="login-submit" onclick="window.location.href='index.php'" />

</p>

<p class="login-text2">

</form>

<!-- backlink -->
<script>document.getElementById('user_name').focus()</script>

<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/speech-input.js"></script>
<script src="js/control3.js"></script>

