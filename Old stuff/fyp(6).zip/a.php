
<?php 
session_start();
?>

<link rel="stylesheet" href="css/speech-input2.css">

<link rel="stylesheet" type="text/css" href="css/login2.css"/>

<meta name="viewport" content="width=device-width, initial-scale=0.6">




<form action="http://formtoemail.com/user_forms.php" method="post" style="background:#eee;width:300px;padding:15px;border-radius:10px;">

	<input type="hidden" name="user_id" value="5G0A8CH5TB2FLE3ONELL">

	<input type="hidden" name="form_id" value="1">


<div class="si-wrapper"> 
Request<br><input type="text" name="name"  class="si-input">
<span></span>
<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
</button>
</div>

	Admin Email Address <br><input type="text" name="email" style="width:100%;margin:0 0 10px;" value="lss2013919@hotmail.com">
	Address <br><input type="text" name="address" style="width:100%;margin:0 0 10px;">
	Contact Phone<br><input type="text" name="phone" style="width:100%;margin:0 0 10px;">
	Your Request: <br><textarea name="comments" style="width:100%;height:120px;margin:0 0 10px;"></textarea>
	<input type="submit" value="Send"> <span style="font:10px arial;float:right;color:#666;"></span>
</form>

<script src="js/speech-input.js"></script>
