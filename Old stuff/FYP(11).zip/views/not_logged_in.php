

<link rel="stylesheet" type="text/css" href="css/login.css"/>
<link rel="stylesheet" href="css/speech-input.css">

<meta name="viewport" content="width=device-width, initial-scale=0.7">

<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform">

<p class="login-text">

<span>
<img src="images/logo.png"><br>

Login  The Voice Calendar by simply
few step
</span>

<div class="si-wrapper">                   

 <input id="login_input_username" class="si-input login-username login_input" type="text" name="user_name" placeholder="Name" size=50px x-webkit-speech />           

<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>



<br>

<div class="si-wrapper">                   

     <input id="login_input_password" class="si-input login-username login-password" type="password" name="user_password"  required="true" placeholder="Password" required size=50px   />

<button class="si-btn2" id="login_input_password_voicebtn">
		speech input
		<span class="si-mic"></span>
		<span class="si-holder"></span>
	</button>
</div>

    


    <input type="submit" id="loginbtn" name="login" value="Log in"  class="login-submit"/>
<input type="button"  value="No Account?Go Register"  class="login-submit" onclick="window.location.href='register.php'" />

  </p>

<script>document.getElementById('login_input_username').focus();</script>








<p class="login-text2">

<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>


</form>
<!--

<input name="speech-msg2" id="speech-msg2" type="hidden" value="Please speak aloud your login name and login password ">

  <p id="msg2"></p>

	
        <input type="hidden" id="voice2" value="native">
		<input type="hidden" name="volume2" id="volume" value="1">
		<input type="hidden" name="rate2" id="rate" value="1">
		<input type="hidden" name="pitch2" id="pitch" value="1">

<br>

<input type="hidden" id="speak2" value="">

<script>
window.onload = function(){
	document.getElementById('speak2').click();
}
</script>
-->


<a href="register.php" class="login-forgot-pass">No Account?Register the account now</a>



<input name="speech-msg" id="speech-msg" type="hidden" value="User : welcome to the Voice Calendar System :  I am A I of Voice Calendar System : Our system supports voice control functions : If you want to input your information by voice : Please speak aloud : automatic : Our System could run an array of procedure : for record your voice as input :  as well as login procedure : If you want to register your account : Please speak aloud : Register : Thank You for your corporation ">

  <p id="msg"></p>

	
                        <input type="hidden" id="voice" value="native">
		<input type="hidden" name="volume" id="volume" value="1">
		<input type="hidden" name="rate" id="rate" value="1">
		<input type="hidden" name="pitch" id="pitch" value="1">

<br>

<input type="hidden" id="speak" value="">

<script>
window.onload = function(){
document.getElementById('speak').click();
}
</script>




<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/voice.js"></script>
<!--<script src="js/voice2.js"></script>-->
<script src="js/speech-input.js"></script>
<script src="js/control.js"></script>

