/*
 * Check for browser support
 */
 
 
var supportMsg = document.getElementById('msg2');

if ('speechSynthesis' in window) {
	supportMsg.innerHTML = '    ';
} else {
	supportMsg.innerHTML = 'Sorry your browser <strong>does not support</strong> speech synthesis.<br>Try this in <a href="http://www.google.co.uk/intl/en/chrome/browser/canary.html">Chrome Canary</a>.';
	supportMsg.classList.add('not-supported');
}


// Get the 'speak' button
var button = document.getElementById('speak2');

// Get the text input element.
var speechMsgInput = document.getElementById('speech-msg2');

// Get the voice select element.
var voiceSelect = document.getElementById('voice2');

// Get the attribute controls.
var volumeInput = document.getElementById('volume2');
var rateInput = document.getElementById('rate2');
var pitchInput = document.getElementById('pitch2');


// Fetch the list of voices and populate the voice options.
function loadVoices() {
  // Fetch the available voices.
	var voices = speechSynthesis.getVoices();
  
  // Loop through each of the voices.
	voices.forEach(function(voice2, i) {
    // Create a new option element.
		var option = document.createElement('option');
    
    // Set the options value and text.
		option.value = voice2.name;
		option.innerHTML = voice2.name;
		  
    // Add the option to the voice selector.
		voiceSelect.appendChild(option);
	});
}

// Execute loadVoices.
loadVoices();

// Chrome loads voices asynchronously.
window.speechSynthesis.onvoiceschanged = function(e) {
  loadVoices();
};


// Create a new utterance for the specified text and add it to
// the queue.
function speak(text) {
  // Create a new instance of SpeechSynthesisUtterance.
	var msg2 = new SpeechSynthesisUtterance();






  
  // Set the text.
	msg2.text = text;
            msg2.voiceURI = 'native';
            msg2.lang = 'en-US';

  // Set the attributes.
	msg.volume2 = parseFloat(volumeInput.value);
	msg.rate2 = parseFloat(rateInput.value);
	msg.pitch2 = parseFloat(pitchInput.value);
  
  // If a voice has been selected, find the voice and set the
  // utterance instance's voice attribute.
	if (voiceSelect.value2) {
		msg2.voice2 = speechSynthesis.getVoices().filter(function(voice2) { return voice2.name == voiceSelect.value; })[0];
	}
  
  // Queue this utterance.
	window.speechSynthesis.speak(msg2);
}


// Set up an event listener for when the 'speak' button is clicked.
button.addEventListener('click', function(e) {
	if (speechMsgInput.value.length > 0) {
		speak(speechMsgInput.value);
	}
});
