<link rel="stylesheet" type="text/css" href="css/login.css"/>
<link rel="stylesheet" href="css/speech-input.css">

<meta name="viewport" content="width=device-width, initial-scale=0.7">

<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform">

<p class="login-text">

<span>
<img src="images/logo.png"><br>

Welcome to The Voice Calendar System 
Please select your choice
</span>

<input type="button"  id="login" value="Login Page"  class="login-submit" onclick="window.location.href='index.php'" />


<input type="button"  id="register" value="No Account?Go Register"  class="login-submit" onclick="window.location.href='register.php'" />







<input name="speech-msg" id="speech-msg" type="hidden" value="User : Please select your action : If you want to Login : Please speak aloud : login : If you want to Register Account : Please speak aloud : Register ">

  <p id="msg"></p>

	
                        <input type="hidden" id="voice" value="native">
		<input type="hidden" name="volume" id="volume" value="1">
		<input type="hidden" name="rate" id="rate" value="1">
		<input type="hidden" name="pitch" id="pitch" value="1">

<br>

<input type="hidden" id="speak" value="">



<script>
window.onload = function(){
document.getElementById('speak').click();
}
</script>





<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/voice.js"></script>
<script src="js/speech-input.js"></script>
<script src="js/index.js"></script>
