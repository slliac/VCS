

<!DOCTYPE HTML>
<html>
	<head>
		<title>Main Page</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<script src="js/jquery.min.js"></script>
        <script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
        
        
		<script src="js/init.js"></script>
	<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			
            <link rel="stylesheet" href="css/font-awesome.min.css" />
            
		</noscript>
	</head>
	<body class="index loading">
	
		<!-- Header -->
<section id="banner">
<header id="header" class="alt">
				
		  <nav id="nav">
					<ul>
						<li class="submenu">


<a href="index.php">Hello,<?php echo $_SESSION['user_name']; ?></a>

							

							<ul>
<li><a href="index.php">Index</a></li>
								<li><a href="sample.php">Schedule</a></li>
								<li><a href="update.php">Contact Adminstrater</a></li>
						
<li><a href="guideline.php">View User Information</a></li>
		

			</ul>

<li><a href="index.php?logout" class="button special">Logout</a></li>
							</ul>
						</li>
			</ul>
			  </nav>
</header>


		<!-- Banner -->		
			
<div class="inner">				
					<header>
				<h2>Voice<br> Calendar</h2>
					</header>
					<p><strong>Listen</strong> Timetable by Voice.<br><BR>
                    <p>
                    <strong>Input </strong>your information
                by Voice</p><br>

 <p>
                    <strong>Control </strong>your Timetable
                by Voice</p>


<footer>
						<ul class="buttons vertical">
							<li><a href="sample.php" class="button">&nbsp;&nbsp;&nbsp;CHECK YOUR SCHEDULE NOW&nbsp;&nbsp;&nbsp;</a></li>
						</ul>
					</footer>
			</div>
</section id="banner">	
		<!-- Main -->

<header class="special container"> 

<img src="images/Entypo_2712(0)_128.png" width="128" height="128" alt="IMAGE2">
<h2> Send the request for your adminstrators <strong>EASILY </strong></h2>

  <p>By Our System,Our Coordniators and System Adminstrators would contact you as soon as possible.Our Adminstrators are nice to answer your quesitons.</p>
			  <p>             </p>
	  <ul class="buttons">
		<li><a href="update.php" class="button">Contact Our Adminstrtator</a></li>
	  </ul>                    
</header>

                                        
		
			<section id="cta">


		  <header>
					<h2>Check Your information</h2>
					<p>Our tools also show the detailed infomarion that your personal information had registered.</p>
				</header>


				<footer>
					<ul class="buttons">
						<li><a href="guideline.php" class="button special">Check Your Profile and Information </a></li>
					
				  </ul>
		        </footer>
			
			</section>

 




<!-- Footer -->
			<footer id="footer">
			
            <a href="main.php"><img src="images/Entypo_2302(0)_32.png" width="64" height="64" alt="home"> </a>
            <a href="update.php"><img src="images/Entypo_d83d(0)_64.png" width="64" height="64" alt="personal"></a>


<a href="sample.php"><img src="images/Entypo_e731(0)_32.png" width="64" height="64" alt="schedule"></a>

            <a href="index.php?logout"><img src="images/Entypo_e715(0)_32.png" width="64" height="64" alt="logout"></a>
            <br><br><br><br>
   <p align="center">ISD02 Final Year Project Version 2.0
    <br>Information System Development
    <br>Community College of City University 
    
    </p>    
            </footer>
            
            
            
            
	<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script></div>


<input name="speech-msg" id="speech-msg" type="hidden" value="User : welcome to the main page : If you want to go to Schedule page: Please  speak aloud : Schedule : If you want to go to Profile page : please speak aloud : profile : If you want want to check syntax for voice control function : please speak aloud :  Help : Thank You for your corporation ">

  <p id="msg"></p>

	
                        <input type="hidden" id="voice" value="native">
		<input type="hidden" name="volume" id="volume" value="1">
		<input type="hidden" name="rate" id="rate" value="1">
		<input type="hidden" name="pitch" id="pitch" value="1">

<br>

<input type="hidden" id="speak" value="">

<script>
window.onload = function(){
document.getElementById('speak').click();
}
</script>


<script src="js/voice.js"></script>

</body>
</html>