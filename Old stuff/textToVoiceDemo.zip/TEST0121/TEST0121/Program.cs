﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Speech.AudioFormat;
using Microsoft.Speech.Synthesis;

namespace TEST0121
{
    class Program
    {
        static void Main(string[] args)
        {
        tryagain:
            string words;
             int VID = 1;
            SpeechSynthesizer synth = new SpeechSynthesizer();
            synth.SelectVoice("Microsoft Server Speech Text to Speech Voice (zh-TW, HanHan)");
            synth.Volume = 100;
            synth.Rate = -3;
            words = Console.ReadLine();
            try
            {
                synth.SetOutputToWaveFile("Voice" + VID + ".wav", new SpeechAudioFormatInfo(32000, AudioBitsPerSample.Sixteen, AudioChannel.Mono));
                synth.Speak(words);

                Process p = Process.Start("lame.exe", "-f " + "Voice" + VID + ".wav " + "Voice" + VID + ".mp3");
                VID++;
                p.WaitForExit();

                Console.Read(); 
            }
            catch {
                synth.SetOutputToNull();
                goto tryagain;
            }
        }
    }
}
