var colors = { 
    logout:  'logout', 
    lockout: 'lockout',
    listen:  'listen',
    create: 'create',
    save: 'save',
	close: 'close',
};
var keys = Object.keys( colors );
var speech = new webkitSpeechRecognition();
speech.language = 'en-US';
speech.continuous = true;
speech.interimResults = true;
speech.onresult = function( e ) {
    if ( e.results[e.results.length-1].isFinal) {
      var said = e.results[e.results.length-1][0].transcript.toLowerCase();
      //output.textContent = said;
	  console.log(said);
        //for (var i = keys.length - 1; i >= 0; i--) {
            var sanitized_said = said.trim().replace(/ /g,'')
			document.activeElement.value = sanitized_said;


if(document.activeElement == document.getElementById('login_input_username')){
                    
		document.getElementById('login_input_email').focus();
                        document.getElementById("audio2").click();
}

			else if(document.activeElement == document.getElementById('login_input_email')){

			   document.getElementById('login_input_password_new').focus();
                                       document.getElementById("audio3").click();
}

			else if(document.activeElement == document.getElementById('login_input_password_new')){
				document.getElementById('login_input_password_repeat').focus();
            document.getElementById("audio4").click();

}

			else document.getElementById('registerbtn').click();
            
				//document.getElementByClass("bubble-sprite").click();
				//window.Edit(data);
				//document.getElementById().click();
			}
        //};
    };


speech.start();