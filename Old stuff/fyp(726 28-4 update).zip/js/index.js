var speech = new webkitSpeechRecognition();
speech.language = 'en-US';
speech.continuous = true;
speech.interimResults = true;
speech.onresult = function( e ) {
    if ( e.results[e.results.length-1].isFinal) {
      var said = e.results[e.results.length-1][0].transcript.toLowerCase();
	  console.log(said);
            var sanitized_said = said.trim().replace( ' ', '' );

            if ( sanitized_said === 'speak' ) {
				document.getElementById("speak").click();
            } 
			
			else if ( sanitized_said === 'create') {
				document.getElementById("faddbtn").click();
			}
			
		
			else if ( sanitized_said === 'save'|| sanitized_said === 'safe') {
				document.getElementById("Savebtn").click();
			}
			
			else if ( sanitized_said === 'delete') {
				document.getElementById("Deletebtn").click();
			}
			
			else if ( sanitized_said === 'close') {
				document.getElementById("Closebtn").click();
			}

			else if ( sanitized_said === 'login'|| sanitized_said === 'log in') {
				document.getElementById("login").click();
			}

	        else if ( sanitized_said === 'register') {
				document.getElementById("register").click();
			}

			else if(sanitized_said == 'main' || sanitized_said == 'men'  )
{
	window.location.href ='index.php';
} 

		
			else if ( sanitized_said === 'lockout' || sanitized_said === 'logout' || sanitized_said == 'lock out' ) {
                window.location.href = 'index.php?logout';
            } else if ( sanitized_said === 'insert'|| sanitized_said === 'new') {
				(function(e) {
				
                //var url ="edit.php";
                //OpenModelWindow(url,{ width: 500, height: 400, caption: "Create New Calendar"});
            });
				//document.getElementByClass("bubble-sprite").click();
				//window.Edit(data);
				//document.getElementById().click();
			}
        //};
    };
}

speech.start();