<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Page</title>
<style type="text/css">
.abc {
	font-family: Verdana, Geneva, sans-serif;
}
.abc {
	font-size: 10px;
}
.def {
	font-weight: bold;
	font-size: 12px;
	font-family: Verdana, Geneva, sans-serif;
}
.ijk {
	font-family: Verdana, Geneva, sans-serif;
}
.ijk {
	font-family: Verdana, Geneva, sans-serif;
}
.poi {
	font-family: Tahoma, Geneva, sans-serif;
}
.def {
	font-family: Verdana, Geneva, sans-serif;
}
.def {
	font-size: 10px;
}
.def .def {
	font-weight: normal;
}
</style>
</head>

<body>
<p><img src="logo.png" width="249" height="95"

 /></p>
<p><img src="wall.png" width=100% height="301" /></p>
<p class="abc"> Please login Voice Calender by entered the username and password.</p>
<p class="def">To protected your privacy,please remember to logout while exit your browser and when you finished.</p>
<p class="def">&nbsp;</p>


<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform" id="form">

<p class="login-text">




 <input id="login_input_username" class="login-username login_input" type="text" name="user_name" placeholder="Name" size=50px x-webkit-speech />           



<br>
<br>
<br>



     <input id="login_input_password" class="login-username login-password" type="password" name="user_password"  required="true" placeholder="Password" required size=50px   />

    <br><br>


    <input type="submit" id="loginbtn" name="login" value="Log in"  class="login-submit"/>

<input type="button"  value="Register as adminstrator"  class="login-submit" onclick="window.location.href='register.php'" />

  </p>

<script>document.getElementById('login_input_username').focus();</script>








<p class="login-text2">

<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>


</form>


<br><br><br><br><br><br>
<hr>
<p class="abc">
Copyright Google Voice Calender Admin Version 1.0 2015
<BR>ISD02
Final Year Project in Information System Development<br>
Community College of City University</p>
</p>




