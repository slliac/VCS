
<?php 
session_start();
?>

<meta name="viewport" content="width=device-width, initial-scale=0.7">
<link rel="stylesheet" type="text/css" href="css/login2.css"/>
<meta name="viewport" content="width=device-width, initial-scale=0.6">



<form action="http://formtoemail.com/user_forms.php" method="post" class="login-form" name="loginform" id="form">

<input type="hidden" name="user_id" value="5G0A8CH5TB2FLE3ONELL">
<input type="hidden" name="form_id" value="1">

<p class="login-text">
<span>
<img src="images/info.png">
</span>

<br>
View Your personal information 

<br><br>

<h5></h5>
    <!-- the user name input field uses a HTML5 pattern check -->


    Your registered User Name: 
<br><br>
<b><?php echo $_SESSION['user_name'];?></b> 
<span></span>
<br><br>



<br>

    <!-- the email input field uses a HTML5 email type check -->

Your  registered email :

<br><br>
             <b><?php echo $_SESSION['user_email'];?></b>  
<span></span>
<br>

<br>
    <input type="button"  value="Back to main page"  class="login-submit" onclick="window.location.href='index.php'" />

</p>


<p class="login-text2">


</form>

<!-- backlink -->


<div class="underlay-photo"></div>
<div class="underlay-black"></div> 

<script src="js/speech-input.js"></script>
