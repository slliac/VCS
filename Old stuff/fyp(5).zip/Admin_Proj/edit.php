

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Page</title>
<style type="text/css">
.poi {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 10px;
}
#left p {
	font-weight: bold;
	font-family: Verdana, Geneva, sans-serif;
	color: #C00;
	font-size: 12px;
}
fgh {
	font-size: 9px;
}
bef {
	font-size: 9px;
}
.fer {
	font-size: 12px;
	color: #0FF;
}
.abc {
	font-size: 12px;
}
.a {
	font-size: 14px;
}
.SS {
	color: #C03;
}
.sta {
	font-weight: bold;
	font-family: Arial, Helvetica, sans-serif;
}
#right p {
	font-family: Verdana, Geneva, sans-serif;
	font-weight: bold;
}
</style>
<link href="index.css" rel="stylesheet" type="text/css" />
</head>

<body>
<p><img src="logo.png" width="249" height="95" align="left"/>
  
  <br>
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p><br>
    
  
  <img src="wall.png" width=100% height="301" /></p>
<div id="left">
  <p class="SS">Now yare login as:  </p>
  
 <div id="admin">Admin1234<A HREF="login.html"><img src="Entypo_e78e(0)_32.png" width="32" height="32" /><BR>
  </a> </div>
  <span class="sta"><a href="login.html">[logout]</a></span>
  <br><br>
  <div class="a" id="currentpage"><img src="Entypo_2691(0)_32.png" width="32" height="32" />Current:Edit.php
</div>
  <p><img src="Entypo_e792(0)_32.png" width="32" height="32" />Your Page Index:<br> 
<img src="Entypo_2712(0)_32.png" width="32" height="32" /> <a href="view.php">Profile</a></p>
  <p><span class="asd"><img src="Entypo_d83d(0)_32.png" width="32" height="32" /><a href="backup.html">Backup </a></span></p>
  <p>&nbsp;</p>
  
</div>


<div id="right">
  <div id="update">
 <fieldset>
  <legend>Admin for users info:</legend>


















<?php
/* 
 EDIT.PHP
 Allows user to edit specific entry in database
*/

 // creates the edit record form
 // since this form is used multiple times in this file, I have made it a function that is easily reusable
 function renderForm($id, $firstname, $lastname, $error)
 {
 ?>
 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
 <html>
 <head>
 <title>Edit Record</title>
 </head>
 <body>
 <?php 
 // if there are any errors, display them
 if ($error != '')
 {
 echo '<div style="padding:4px; border:1px solid red; color:red;">'.$error.'</div>';
 }
 ?> 

 <form action="" method="post">
 <input type="hidden" name="id" value="<?php echo $id; ?>"/>
 <div>
 <p><strong>ID:</strong> <?php echo $id; ?></p>
 <strong>User Name: *</strong> <input type="text" name="firstname" value="<?php echo $firstname; ?>"/><br/>
 <strong>User Email: *</strong> <input type="text" name="lastname" value="<?php echo $lastname; ?>"/><br/>
 <p>* Required</p>
 <input type="submit" name="submit" value="Submit">
 </div>
 </form> 

 <?php
 }



 // connect to the database
 include('connect-db.php');
 
 // check if the form has been submitted. If it has, process the form and save it to the database
 if (isset($_POST['submit']))
 { 
 // confirm that the 'id' value is a valid integer before getting the form data
 if (is_numeric($_POST['id']))
 {
 // get form data, making sure it is valid
 $id = $_POST['id'];
 $firstname = mysql_real_escape_string(htmlspecialchars($_POST['firstname']));
 $lastname = mysql_real_escape_string(htmlspecialchars($_POST['lastname']));
 
 // check that firstname/lastname fields are both filled in
 if ($firstname == '' || $lastname == '')
 {
 // generate error message
 $error = 'ERROR: Please fill in all required fields!';
 
 //error, display form
 renderForm($id, $firstname, $lastname, $error);
 }
 else
 {
 // save the data to the database
 mysql_query("UPDATE users JOIN jqcalendar ON users.user_name=jqcalendar.user
SET users.user_name='$firstname', jqcalendar.user='$firstname', users.user_email='$lastname' 
WHERE users.user_id='$id' ; ")
 or die(mysql_error()); 
 
 // once saved, redirect back to the view page
 header("Location: view.php"); 
 }
 }
 else
 {
 // if the 'id' isn't valid, display an error
 echo 'Error!';
 }
 }
 else
 // if the form hasn't been submitted, get the data from the db and display the form
 {
 
 // get the 'id' value from the URL (if it exists), making sure that it is valid (checing that it is numeric/larger than 0)
 if (isset($_GET['id']) && is_numeric($_GET['id']) && $_GET['id'] > 0)
 {
 // query db
 $id = $_GET['id'];
 $result = mysql_query("SELECT * FROM users WHERE user_id=$id")
 or die(mysql_error()); 
 $row = mysql_fetch_array($result);
 
 // check that the 'id' matches up with a row in the databse
 if($row)
 {
 
 // get data from db
 $firstname = $row['user_name'];
 $lastname = $row['user_email'];
 
 // show form
 renderForm($id, $firstname, $lastname, '');
 }
 else
 // if no match, display result
 {
 echo "No results!";
 }
 }
 else
 // if the 'id' in the URL isn't valid, or if there is no 'id' value, display an error
 {
 echo 'Error!';
 }
 }
?>

</fieldset>
 </body>
 </html> 

