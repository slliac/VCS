
<link rel="stylesheet" href="css/speech-input.css">
<link rel="stylesheet" type="text/css" href="css/login4.css"/>
<meta name="viewport" content="width=device-width, initial-scale=0.7">

<!-- login form box -->
<form method="post" class="login-form" action="index.php" name="loginform" id="form">

<p class="login-text">

<span>
<img src="images/login.png"><br>

Login  The Voice Calendar by simply
few step
</span>

<div class="si-wrapper">                   

 <input id="login_input_username" class="si-input login-username login_input" type="text" name="user_name" placeholder="Name" size=50px x-webkit-speech />           

<button class="si-btn2" id="login_input_username_voicebtn">
		speech input
		<span class="si-mic" ></span>
		<span class="si-holder"></span>
	</button>
</div>



<br>
<br>
<br>

<div class="si-wrapper">                   

     <input id="login_input_password" class="si-input login-username login-password" type="password" name="user_password"  required="true" placeholder="Password" required size=50px   />

<button class="si-btn2" id="login_input_password_voicebtn">
		speech input
		<span class="si-mic"></span>
		<span class="si-holder"></span>
	</button>
</div>

    


    <input type="submit" id="loginbtn" name="login" value="Log in"  class="login-submit"/>

<input type="button"  value="Back to main page"  class="login-submit" onclick="window.location.href='new_index.php'" />

  </p>

<script>document.getElementById('login_input_username').focus();</script>








<p class="login-text2">

<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>


</form>




<audio autoplay>
 <source src="voice/name1.mp3" type="audio/mpeg">
</audio>


<audio id="myaudio" src="voice/pw.mp3" ></audio>

<input type="hidden" id="audio" onclick="document.getElementById('myaudio').play()">


<audio id="myaudio" src="voice/pw.mp3" ></audio>

<input type="hidden" id="audio" onclick="document.getElementById('myaudio').play()">

<audio id="myaudio2" src="voice/auto.mp3" ></audio>

<input type="hidden" id="audio2" onclick="document.getElementById('myaudio2').play()">





<!--

<input name="speech-msg2" id="speech-msg2" type="hidden" value="Please speak aloud your login name and login password ">

  <p id="msg2"></p>

	
        <input type="hidden" id="voice2" value="native">
		<input type="hidden" name="volume2" id="volume" value="1">
		<input type="hidden" name="rate2" id="rate" value="1">
		<input type="hidden" name="pitch2" id="pitch" value="1">

<br>

<input type="hidden" id="speak2" value="">

<script>
window.onload = function(){
	document.getElementById('speak2').click();
}
</script>
-->
















<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
<script src="js/voice.js"></script>
<!--<script src="js/voice2.js"></script>-->
<script src="js/speech-input.js"></script>
<script src="js/control.js"></script>

