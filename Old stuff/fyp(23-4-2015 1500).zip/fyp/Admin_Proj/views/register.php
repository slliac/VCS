<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="css/login2.css"/>
<link rel="stylesheet" type="text/css" href="index.css"/>
<link rel="stylesheet" href="css/speech-input.css">
<meta name="viewport" content="width=device-width, initial-scale=0.7">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login Page</title>
<style type="text/css">
.abc {
	font-family: Verdana, Geneva, sans-serif;
}
.abc {
	font-size: 10px;
}
.def {
	font-weight: bold;
	font-size: 12px;
	font-family: Verdana, Geneva, sans-serif;
}
.ijk {
	font-family: Verdana, Geneva, sans-serif;
}
.ijk {
	font-family: Verdana, Geneva, sans-serif;
}
.poi {
	font-family: Tahoma, Geneva, sans-serif;
}
.def {
	font-family: Verdana, Geneva, sans-serif;
}
.def {
	font-size: 10px;
}
.def .def {
	font-weight: normal;
}
</style>
</head>

<body>
<p><img src="logo.png" width="249" height="95"

 /></p>

<p><img src="wall.png" width=100% height="301" /></p>
<p class="abc"> Please login Voice Calender by entered the username and password.</p>
<p class="def">To protected your privacy,please remember to logout while exit your browser and when you finished.</p>
<p class="def">&nbsp;</p>

<!-- register form -->
<form method="post" action="register.php" name="registerform" class="login-form">

<p class="login-text">

    <!-- the user name input field uses a HTML5 pattern check -->
<p class="abc">User name:</p>
    <input id="login_input_username" class="login-username  si-input "   type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" placeholder="Username (only letters and numbers, 2 to 64 characters)" required size=100px />


<BR><br>


    <!-- the email input field uses a HTML5 email type check -->
<p class="abc">Email:</p>

    <input id="login_input_email" class="login-username  si-input " type="text" name="user_email" placeholder="User Email"required size=100px />

<BR><br>

<p class="abc">Password:</p>

    <input id="login_input_password_new" class="login-username  si-input " type="password" name="user_password_new" pattern=".{6,}" required autocomplete="off" placeholder="password" required size=100px />

<BR><BR>

<p class="abc">Repeat Password:</p>

    <input id="login_input_password_repeat" class="login-username  si-input " type="password" name="user_password_repeat" pattern=".{6,}" required autocomplete="off" placeholder="repeat password" required size=100px />


<BR><BR><br>


    <input type="submit"  id="submit" name="register" value="Register" id="registerbtn" class="login-submit" />
    <input type="button"  value="Back to main page"  class="login-submit" onclick="window.location.href='index.php'" />

</p>

<p class="login-text2">
<?php
// show potential errors / feedback (from registration object)
if (isset($registration)) {
    if ($registration->errors) {
        foreach ($registration->errors as $error) {
            echo $error;
        }
    }
    if ($registration->messages) {
        foreach ($registration->messages as $message) {
            echo $message;
        }
    }
}
?>

</p>
</form>

<!-- backlink -->


<audio autoplay>
 <source src="voice/name2.mp3" type="audio/mpeg">
</audio>

<audio id="myaudio2" src="voice/email.mp3" ></audio>

<input type="hidden" id="audio2" onclick="document.getElementById('myaudio2').play()">

<audio id="myaudio3" src="voice/pw2.mp3" ></audio>

<input type="hidden" id="audio3" onclick="document.getElementById('myaudio3').play()">

<audio id="myaudio4" src="voice/confirm.mp3" ></audio>

<input type="hidden" id="audio4" onclick="document.getElementById('myaudio4').play()">


</body>
</html>


