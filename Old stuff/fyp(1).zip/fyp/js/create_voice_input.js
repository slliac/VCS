var speech = new webkitSpeechRecognition();
var now = new Date();
var yy = now.getFullYear();
speech.language = 'en-US';
speech.continuous = true;
speech.interimResults = true;
speech.onresult = function( e ) {
	if ( e.results[e.results.length-1].isFinal){
		var said = e.results[e.results.length-1][0].transcript.toLowerCase();
		console.log(said); //original input for debugging
		var sanitized_said = said.trim();
		
		//user can speak last/this/next year to input year
		if(document.activeElement == document.getElementById('stYY')||document.activeElement == document.getElementById('etYY')){
			if(sanitized_said == 'last year')
				sanitized_said = now.getFullYear()-1;
			if(sanitized_said == "this year")
				sanitized_said = now.getFullYear();
			if(sanitized_said == 'next year')
				sanitized_said = now.getFullYear()+1;
		}
		//user can speak the name of those months to input months
		if(document.activeElement == document.getElementById('stMM')||document.activeElement == document.getElementById('etMM')){
			if(sanitized_said == 'january')
				sanitized_said = '01';
			if(sanitized_said == 'february')
				sanitized_said = '02';
			if(sanitized_said == 'march')
				sanitized_said = '03';
			if(sanitized_said == 'april')
				sanitized_said = '04';
			if(sanitized_said == 'may')
				sanitized_said = '05';
			if(sanitized_said == 'june')
				sanitized_said = '06';
			if(sanitized_said == 'july')
				sanitized_said = '07';
			if(sanitized_said == 'august')
				sanitized_said = '08';
			if(sanitized_said == 'september')
				sanitized_said = '09';
			if(sanitized_said == 'october')
				sanitized_said = '10';
			if(sanitized_said == 'november')
				sanitized_said = '11';
			if(sanitized_said == 'december')
				sanitized_said = '12';
			//user can speak last/this/next month to input month
			//getMonth() 0 = January 1 = February
			if(sanitized_said == 'last month')
				sanitized_said = now.getMonth();
			if(sanitized_said == 'this month')
				sanitized_said = now.getMonth()+1;
			if(sanitized_said == 'next month')
				sanitized_said = now.getMonth()+2;
			//user can speak ? months later to input month
			if(sanitized_said.toString().indexOf('months later') != -1)
			{
				sanitized_said = now.getMonth()-(-1-sanitized_said.replace(/months later/," "));
				console.log("executed");
			}
		}
		//user can speak today next day tomorrow yesterday  to input date
		//user can also speak twenty first twenty second and so on to input date
		if(document.activeElement == document.getElementById('stDD')||document.activeElement == document.getElementById('etDD')){
			if(sanitized_said == 'yesterday')
				sanitized_said = now.getDate()-1;
			if(sanitized_said == 'today')
				sanitized_said = now.getDate();
			if(sanitized_said == 'tomorrow' || sanitized_said == 'next day')
				sanitized_said = now.getDate()+1;
			if(sanitized_said.toString().indexOf('days later') != -1)
			{
				sanitized_said = now.getDate()-(0-sanitized_said.replace(/days later/," "));
				console.log("executed");
			}
			//eliminate st nd rd th 
			if(sanitized_said.toString().indexOf('st') != -1)
			{
				sanitized_said = sanitized_said.replace(/st/," ");
			}else if(sanitized_said.toString().indexOf('nd') != -1)
					sanitized_said = sanitized_said.replace(/nd/," ");
					else if(sanitized_said.toString().indexOf('rd') != -1)
						sanitized_said = sanitized_said.replace(/rd/," ");
						else if(sanitized_said.toString().indexOf('th') != -1)
							sanitized_said = sanitized_said.replace(/th/," ");
						
		}
		//user can speak now (current hour) and ? hours later to input hour
		if(document.activeElement == document.getElementById('stHour')||document.activeElement == document.getElementById('etHour')){
			if(sanitized_said == 'now')
				sanitized_said = now.getHours();
			if(sanitized_said == "this hour")
				sanitized_said = now.getHours();
			if(sanitized_said == 'next hour')
				sanitized_said = now.getHours()+1;
			if(sanitized_said.toString().indexOf('hours later') != -1)
			{
				sanitized_said = now.getHours()-(0-sanitized_said.replace(/hours later/," "));
			}
		}
		
		//user can speak now and ? minutes later to input minute
		if(document.activeElement == document.getElementById('stMin')||document.activeElement == document.getElementById('etMin')){
			now = new Date();
			if(sanitized_said == 'now')
				sanitized_said = now.getMinutes();
			if(sanitized_said.toString().indexOf('minutes later') != -1)
			{
				sanitized_said = now.getMinutes()-(0-sanitized_said.replace(/minutes later/," "));
			}
		}
		document.activeElement.value = sanitized_said;
		if(document.activeElement != document.getElementById('Subject') && 
			document.activeElement != document.getElementById('Location') && 
			document.activeElement != document.getElementById('Description')){
				if(isNaN(sanitized_said))
				{
					
					console.log("YY");
				}else console.log("NN");
		}
		//flow of speech input
		if(document.activeElement == document.getElementById('Subject')){
            document.getElementById('stYY').focus();
            document.getElementById("audio2").click(); 
		}else if(document.activeElement == document.getElementById('stYY')){
			if(isNaN(sanitized_said))
			{
				document.getElementById('stYY').focus();
				document.getElementById("audio2").click(); 
			}else{
				document.getElementById('stMM').focus();
				document.getElementById("audio3").click(); 
			}
		}else if(document.activeElement == document.getElementById('stMM')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('stMM').focus();
				document.getElementById("audio3").click(); 
			}else{
				document.getElementById('stDD').focus();
				document.getElementById("audio4").click();
			}
		}else if(document.activeElement == document.getElementById('stDD')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('stDD').focus();
				document.getElementById("audio4").click(); 
			}else{
				document.getElementById('stHour').focus();
				document.getElementById("audio5").click();
			}
		}else if(document.activeElement == document.getElementById('stHour')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('stHour').focus();
				document.getElementById("audio5").click(); 
			}else{
				document.getElementById('stMin').focus();
                document.getElementById("audio6").click();
			}
		}else if(document.activeElement == document.getElementById('stMin')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('stMin').focus();
				document.getElementById("audio6").click(); 
			}else{
				document.getElementById('etYY').focus();
				document.getElementById("audio10").click();
			}				
		}else if(document.activeElement == document.getElementById('etYY')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('etYY').focus();
				document.getElementById("audio10").click(); 
			}else{
				document.getElementById('etMM').focus();
                document.getElementById("audio11").click(); 
			}
		}else if(document.activeElement == document.getElementById('etMM')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('etMM').focus();
				document.getElementById("audio11").click(); 
			}else{
				document.getElementById('etDD').focus();
				document.getElementById("audio12").click();
			}
		}else if(document.activeElement == document.getElementById('etDD')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('etDD').focus();
				document.getElementById("audio12").click(); 
			}else{
				document.getElementById('etHour').focus();
				document.getElementById("audio13").click(); 
			}
		}else if(document.activeElement == document.getElementById('etHour')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('etHour').focus();
				document.getElementById("audio13").click(); 
			}else{
				document.getElementById('etMin').focus();
                document.getElementById("audio14").click(); 
			}
		}else if(document.activeElement == document.getElementById('etMin')){
		if(isNaN(sanitized_said))
			{
				document.getElementById('etMin').focus();
				document.getElementById("audio14").click(); 
			}else{
				document.getElementById('Location').focus();
				document.getElementById("audio8").click(); 
			}
		}else if(document.activeElement == document.getElementById('Location')){
			document.getElementById('Description').focus();
                                    document.getElementById("audio9").click(); 
			//voice hints
		}else if(document.activeElement == document.getElementById('Description')){
			document.getElementById('Savebtn').click();
		}
	}
};


speech.start();